const { Schema, model } = require('mongoose');
const transactionSchema = new Schema({
  playerId: { type: Schema.Types.ObjectId, ref: 'Player' },
  type: { type: String, enum: ['bet', 'cashout'] },
  amount: Number,
  multiplier: Number,
  createdAt: { type: Date, default: Date.now }
});
module.exports = model('Transaction', transactionSchema);