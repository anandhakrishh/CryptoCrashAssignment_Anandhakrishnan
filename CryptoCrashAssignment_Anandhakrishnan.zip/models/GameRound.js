const { Schema, model } = require('mongoose');
const roundSchema = new Schema({
  roundNumber: Number,
  crashPoint: Number,
  seedHash: String,
  startTime: Date,
  endTime: Date
});
module.exports = model('GameRound', roundSchema);