const { Schema, model } = require('mongoose');
const playerSchema = new Schema({
  username: String,
  balance: { type: Number, default: 1000 },
  walletAddress: String
});
module.exports = model('Player', playerSchema);