
# Crypto Crash Backend

A backend implementation of the Crypto Crash game with cryptocurrency API integration, provably fair game logic, and real-time multiplayer updates using WebSockets.

## Features
- Real-time multiplayer crash game
- Cryptocurrency wallet simulation
- Provably fair crash logic
- Real-time price fetching and caching
- WebSocket support with live updates

## Technologies
- Node.js + Express.js
- MongoDB
- Socket.IO
- CoinGecko API

## Setup Instructions

1. Clone the repository and install dependencies:
   ```bash
   npm install
   ```

2. Configure environment variables in `.env`:
   ```
   PORT=3000
   MONGODB_URI=mongodb://localhost:27017/crypto-crash
   ```

3. Run the server:
   ```bash
   npm start
   ```

4. Seed the database with sample wallets:
   ```bash
   node seed/sampleData.js
   ```

5. Use the Postman collection in the `test/` folder to test endpoints.

## API Endpoints

- `POST /api/bet` — Place a bet
- `POST /api/cashout` — Cash out from the game
- `GET /api/wallet/:playerId` — Get wallet balance

## WebSocket Events

- `connect` — Player connects
- `round_start` — Broadcasts start of round
- `multiplier_update` — Sends multiplier updates every 100ms
- `player_cashout` — Notify all players of a cashout
- `round_crash` — Notify crash point

## Provably Fair Algorithm

Crash point is generated with:
```
hash = SHA256(seed + round_number)
crash_point = parseFloat("1." + hash.slice(0, 2)) * (Math.random() * 100)
```

## License
MIT
