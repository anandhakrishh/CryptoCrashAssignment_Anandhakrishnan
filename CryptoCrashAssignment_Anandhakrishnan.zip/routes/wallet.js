const express = require('express');
const router = express.Router();
const Player = require('../models/Player');

router.get('/:playerId', async (req, res) => {
  try {
    const player = await Player.findById(req.params.playerId);
    if (!player) return res.status(404).json({ message: 'Player not found' });
    res.json({ balance: player.balance });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;