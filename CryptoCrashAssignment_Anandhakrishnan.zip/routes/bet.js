const express = require('express');
const router = express.Router();
const Player = require('../models/Player');
const Transaction = require('../models/Transaction');

router.post('/', async (req, res) => {
  const { playerId, amount } = req.body;
  try {
    const player = await Player.findById(playerId);
    if (!player || player.balance < amount) return res.status(400).json({ message: 'Invalid bet' });

    player.balance -= amount;
    await player.save();

    const tx = new Transaction({ playerId, amount, type: 'bet', multiplier: 0 });
    await tx.save();

    res.json({ message: 'Bet placed', balance: player.balance });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;