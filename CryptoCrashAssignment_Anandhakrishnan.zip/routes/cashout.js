const express = require('express');
const router = express.Router();
const Player = require('../models/Player');
const Transaction = require('../models/Transaction');

router.post('/', async (req, res) => {
  const { playerId, multiplier } = req.body;
  try {
    const lastBet = await Transaction.findOne({ playerId, type: 'bet' }).sort({ createdAt: -1 });
    if (!lastBet) return res.status(400).json({ message: 'No active bet' });

    const winAmount = lastBet.amount * multiplier;
    await Player.findByIdAndUpdate(playerId, { $inc: { balance: winAmount } });

    const tx = new Transaction({ playerId, amount: winAmount, type: 'cashout', multiplier });
    await tx.save();

    res.json({ message: 'Cashed out', winAmount });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;