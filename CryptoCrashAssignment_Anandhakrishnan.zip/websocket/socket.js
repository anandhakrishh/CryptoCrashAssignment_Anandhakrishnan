const GameRound = require('../models/GameRound');

module.exports = function (io) {
  let multiplier = 1.0;
  let interval;

  const startGame = () => {
    const crashPoint = parseFloat((Math.random() * 5 + 1).toFixed(2));
    let current = 1.0;
    io.emit('game_start', { crashPoint });

    interval = setInterval(() => {
      current = parseFloat((current + 0.01).toFixed(2));
      io.emit('multiplier_update', current);
      if (current >= crashPoint) {
        clearInterval(interval);
        io.emit('game_crash', crashPoint);
        setTimeout(startGame, 5000);
      }
    }, 100);
  };

  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    socket.emit('connected', 'Welcome to Crypto Crash!');
  });

  startGame();
};